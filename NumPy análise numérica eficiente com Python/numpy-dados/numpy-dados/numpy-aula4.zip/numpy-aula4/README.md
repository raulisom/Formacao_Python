# numpy
Curso de Numpy na Alura
